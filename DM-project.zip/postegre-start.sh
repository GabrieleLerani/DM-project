sudo systemctl stop apache2
sudo systemctl start postgresql@12-main.service
sudo systemctl start postgresql.service
sudo systemctl start postgresql@15-main.service
~                                              
