sudo systemctl start nginx
sudo systemctl start myproject


