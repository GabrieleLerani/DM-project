from flask import Flask
import os


def create_app():
    app = Flask(__name__)
    from .app import main

    # register the blueprint component
    app.register_blueprint(main)

    # DON'T DO THIS IN A PRODUCTION ENVIRONMENT
    app.secret_key = "e73783303fd3b874f170e1946c01ede05fafdb40c01074ad0328c17a3efdb993"
    return app
