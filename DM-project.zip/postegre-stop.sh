sudo systemctl stop postgresql@12-main.service  
sudo systemctl stop postgresql.service
sudo systemctl stop postgresql@15-main.service  
