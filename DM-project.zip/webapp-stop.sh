sudo systemctl stop nginx
sudo systemctl stop myproject

